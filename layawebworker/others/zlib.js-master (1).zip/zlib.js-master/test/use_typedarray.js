var USE_TYPEDARRAY = window.Uint8Array !== void 0;
