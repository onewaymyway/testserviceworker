/** @type {Object} namespace. */
var exports;

/** @type {Object} namespace. */
var process = {};
/** @param {function()} func exec function. */
process.nextTick = function(func) {};

/** @constructor */
var Buffer = function(arg){};

var console = {};
console.log = function(){};
