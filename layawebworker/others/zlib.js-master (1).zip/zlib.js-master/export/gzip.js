goog.require('Zlib.Gzip');

goog.exportSymbol('Zlib.Gzip', Zlib.Gzip);
goog.exportSymbol(
  'Zlib.Gzip.prototype.compress',
  Zlib.Gzip.prototype.compress
);