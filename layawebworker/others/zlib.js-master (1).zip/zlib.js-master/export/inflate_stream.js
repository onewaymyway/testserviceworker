goog.require('Zlib.InflateStream');

goog.exportSymbol('Zlib.InflateStream', Zlib.InflateStream);
goog.exportSymbol(
  'Zlib.InflateStream.prototype.decompress',
  Zlib.InflateStream.prototype.decompress
);
goog.exportSymbol(
  'Zlib.InflateStream.prototype.getBytes',
  Zlib.InflateStream.prototype.getBytes
);